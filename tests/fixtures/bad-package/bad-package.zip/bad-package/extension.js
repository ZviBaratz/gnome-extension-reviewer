import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';

export default class BadPackageExtension extends Extension {
    enable() {}
    disable() {}
}
