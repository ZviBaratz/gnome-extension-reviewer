import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';

export default class ForbiddenPkgFilesTest extends Extension {
    enable() {}
    disable() {}
}
