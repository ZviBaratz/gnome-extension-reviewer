export default class TestExtension {
    enable() {}
    disable() {}
}
